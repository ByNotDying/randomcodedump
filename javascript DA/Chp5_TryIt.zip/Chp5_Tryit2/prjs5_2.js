var num1 = 0;
var num2 = 9999;
if (num1 < num2) {
 window.alert("True");
}
else {
 window.alert("False");
}