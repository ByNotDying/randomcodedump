document.write("I love writing JavaScript, and using external files!");
